#!/bin/bash

dhclient eth0
